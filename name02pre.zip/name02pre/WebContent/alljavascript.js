/**
 * 모음
 */

	
window.addEventListener('load', function() {
	
	
	$("#btn_select").click(function() {
		var ad2 = $("#address2").val();
		var ad3 = $("#address3").val();
		//플라스크 실험
			$.ajax({
				url: 'http://localhost:9000/',
				type: 'GET',
				dataType : 'json',
				data : {1:ad2, 2:ad3},
				success: function(response) {
					var pytext1 = response.a;
					var pytext2 = response.b;
					var value_care = response.c;
					var ehdcount = response.d;
					if(ehdcount==null){
						ehdcount=0;
					}
					//지도 위 정보 기입부
					var pytext = "장소 : "+pytext1+"  "+pytext2+"\n"+" 화재 발생 횟수 : "+ehdcount+"\n";
					//지도 위 정보 출력부
					pytext = pytext.replace(/(?:\r\n|\r|\n)/g, '<br />');
					$("#data_set").html(pytext);
					
					$("#areaTxt").html(pytext1);
					$('#poison_img span').text(value_care+"%");
				 	if(value_care <= 10){
				 		$('#poison_img').attr('class', 'foodPoison lv1');
				 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv1');
						$("#leveld").html("관심");
						$('#content .alertBox .statusInfo .infoTxt').text("지속적인 관심을 통해 만약의 사태에 대비할 수 있습니다.");
				 	}else if(value_care <= 15){
				 		$('#poison_img').attr('class', 'foodPoison lv2');
				 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv2');
						$("#leveld").html("주의");
						$('#content .alertBox .statusInfo .infoTxt').text("평소와 같은 일상이 지속되겠으나 주변에 대한 주의가 필요합니다.");
				 	}else if(value_care <= 30){
				 		$('#poison_img').attr('class', 'foodPoison lv3');
				 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv3');	 		
						$("#leveld").html("경고");
						$('#content .alertBox .statusInfo .infoTxt').text("경각심이 필요한 시기입니다. 각별히 주의하시길 바라며 혹여의 화재에 대비하시길 바랍니다."); 		
				 	}else{
				 		$('#poison_img').attr('class', 'foodPoison lv4');
				 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv4');
						$("#leveld").html("위험");
						$('#content .alertBox .statusInfo .infoTxt').text("화재 위험도가 높습니다. 화재 우려품을 정비하시길 바랍니다.");
				 	}
				},
				error: function(request, status, error) {
					console.log("code:"
					+ request.status + "\n"
					+ "message:"
					+ request.responseText
					+ "\n" + "error:" + error);
				}
			})
		
		
	})
	
	
	//위험도 레벨
	var now = new Date();
	var getToday = new Date(now);
	var getNextMonth = new Date(now.setDate(now.getDate() + 30));

	var getMonth = getToday.getMonth()+1;
	var getNeMonth = getNextMonth.getMonth()+1;
	if(getMonth < 10 || getNeMonth < 10){
		getMonth = "0"+ getMonth;
		getNeMonth = "0" + getNeMonth;
	}
	
	
    var today = getToday.getFullYear() + "-" + getMonth + "-" + getToday.getDate();
    var thirddayDate = getNextMonth.getFullYear() + "-" + getNeMonth + "-" + getToday.getDate();
	
	var leftData = function(){
		return {
			'fp': {'fplv':'lv1', 'fpPercent':0, 'lvtxt':{'lv1':'관심','lv2':'주의','lv3':'경고','lv4':'위험'}},
			'dayStatus': {
				'today':today
				, 'stepBtn':{'yesterday':'','today':'on','tomorrow':'','thirdday':''}
			}
		}
	}//leftData
	
	$('#todayStatus strong').text(today);
	$('.tit span').text(today);
	//위험도 오늘내일모래 클릭 버튼
		$('#todaybtn').click( function(){
	 		$(this).attr('class','today on');
	 		$("#tomorrowbtn").attr('class','tomorrow');
	 		$("#thirddaybtn").attr('class','thirdday');
	 		$('#todayStatus strong').text(today);
			$.ajax({
				url: 'http://localhost:9000/risk-level',
				type: 'GET',
				dataType : 'json',
				success: function(response) {
					
					value_care = response;
					$('#poison_img span').text(value_care+"%");
					if(value_care <= 10){
				 		$('#poison_img').attr('class', 'foodPoison lv1');
				 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv1');
						$("#leveld").html("관심");
						$('#content .alertBox .statusInfo .infoTxt').text("지속적인 관심을 통해 만약의 사태에 대비할 수 있습니다.");
				 	}else if(value_care <= 15){
				 		$('#poison_img').attr('class', 'foodPoison lv2');
				 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv2');
						$("#leveld").html("주의");
						$('#content .alertBox .statusInfo .infoTxt').text("평소와 같은 일상이 지속되겠으나 주변에 대한 주의가 필요합니다.");
				 	}else if(value_care <= 30){
				 		$('#poison_img').attr('class', 'foodPoison lv3');
				 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv3');	 		
						$("#leveld").html("경고");
						$('#content .alertBox .statusInfo .infoTxt').text("경각심이 필요한 시기입니다. 각별히 주의하시길 바라며 혹여의 화재에 대비하시길 바랍니다."); 		
				 	}else{
				 		$('#poison_img').attr('class', 'foodPoison lv4');
				 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv4');
						$("#leveld").html("위험");
						$('#content .alertBox .statusInfo .infoTxt').text("화재 위험도가 높습니다. 화재 우려품을 정비하시길 바랍니다.");
				 	}
				},
				error: function(request, status, error) {
					console.log("error");
				}
			})
	 	});
	 	
	 	$('#thirddaybtn').click( function(){
	 		$(this).attr('class','thirdday on');
	 		$("#tomorrowbtn").attr('class','tomorrow');
	 		$("#todaybtn").attr('class','today');
	 		$('#todayStatus strong').text(thirddayDate);
		
			var value_care;
			//플라스크 실험
				$.ajax({
					url: 'http://localhost:9000/learning-locLv',
					type: 'GET',
					dataType : 'json',
					success: function(response) {
						value_care = response;
						$('#poison_img span').text(value_care+"%");
						if(value_care <= 10){
					 		$('#poison_img').attr('class', 'foodPoison lv1');
					 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv1');
							$("#leveld").html("관심");
							$('#content .alertBox .statusInfo .infoTxt').text("지속적인 관심을 통해 만약의 사태에 대비할 수 있습니다.");
					 	}else if(value_care <= 15){
					 		$('#poison_img').attr('class', 'foodPoison lv2');
					 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv2');
							$("#leveld").html("주의");
							$('#content .alertBox .statusInfo .infoTxt').text("평소와 같은 일상이 지속되겠으나 주변에 대한 주의가 필요합니다.");
					 	}else if(value_care <= 30){
					 		$('#poison_img').attr('class', 'foodPoison lv3');
					 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv3');	 		
							$("#leveld").html("경고");
							$('#content .alertBox .statusInfo .infoTxt').text("경각심이 필요한 시기입니다. 각별히 주의하시길 바라며 혹여의 화재에 대비하시길 바랍니다."); 		
					 	}else{
					 		$('#poison_img').attr('class', 'foodPoison lv4');
					 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv4');
							$("#leveld").html("위험");
							$('#content .alertBox .statusInfo .infoTxt').text("화재 위험도가 높습니다. 화재 우려품을 정비하시길 바랍니다.");
					 	}
					},
					error: function(request, status, error) {
						console.log("error");
					}
				})
	 	});
	 	
	
	
	
	
	//우측 두번째 선택부
	$('#poison_tab1').click( function(){
	$(this).attr('class','tabtlt tab01 on');
	$('#poison_tab2').attr('class','tabtlt tab02');
	$('#tab01-content').attr('class', 'tabtlt tab01 on');
	$('#tab02-content').attr('class', 'tabtlt tab02');
	});

	$('#poison_tab2').click( function(){
	$(this).attr('class','tabtlt tab02 on');
	$('#poison_tab1').attr('class','tabtlt tab01');
	$('#tab01-content').attr('class', 'tabtlt tab01');
	$('#tab02-content').attr('class', 'tabtlt tab02 on');
	});



var chart1 = c3.generate({
	bindto: '#chart1',
    data: {
        // iris data from R
        columns: [
        	["setosa", 0.2, 0.2, 0.2, 0.2, 0.2],
            ["versicolor", 1.4, 1.5, 1.5, 1.3],
            ["virginica", 2.5, 1.9, 2.1, 1.8]
        ],
        type : 'pie',
    },
    legend: {
        position: 'right'
    }

});

var chart2 = c3.generate({
	bindto: '#chart2',
    data: {
        // iris data from R
        columns: [
        	["test1", 0.2, 0.2, 0.2, 0.2, 0.2],
            ["test2", 1.4, 1.5, 1.5, 1.3],
            ["test3", 2.5, 1.9, 2.1, 1.8]
        ],
        type : 'pie',
    },
    legend: {
        position: 'right'
    }
});
	
	
	
	//상단 클릭 파업창
	$(document).ready(function(){
	    $('.popClose').click(function(){
	        popClose();
	    });
	    $('.riskGuideBtn').click(function(){
	        togglePop();
	    });
	});
	
	
	var togglePop = function(){
	    $('.pop-wrap-toggle').toggle();
	};
	var popClose = function(){
	    togglePop();
	}
	
	
	
	
	
});
	
	
	
	
	
	
	
	
	
	