/**
 * 
 */

window.addEventListener('load', function() {
	
	var now = new Date();
	var getToday = new Date(now);
	var getNextMonth = new Date(now.setDate(now.getDate() + 30));

	var getMonth = getToday.getMonth()+1;
	var getNeMonth = getNextMonth.getMonth()+1;
	if(getMonth < 10 || getNeMonth < 10){
		getMonth = "0"+ getMonth;
		getNeMonth = "0" + getNeMonth;
	}
	
	
    var today = getToday.getFullYear() + "-" + getMonth + "-" + getToday.getDate();
    var thirddayDate = getNextMonth.getFullYear() + "-" + getNeMonth + "-" + getToday.getDate();

	$('#todayStatus strong').text(today);
	$('.tit span').text(today);
	//광주 위험도 레벨
	$.ajax({
		url: 'http://localhost:9000/risk-level',
		type: 'GET',
		dataType : 'json',
		success: function(response) {
			
			value_care = response;
			$('#poison_img span').text(value_care+"%");
			if(value_care <= 10){
		 		$('#poison_img').attr('class', 'foodPoison lv1');
		 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv1');
				$("#leveld").html("관심");
				$('#content .alertBox .statusInfo .infoTxt').text("지속적인 관심을 통해 만약의 사태에 대비할 수 있습니다.");
		 	}else if(value_care <= 15){
		 		$('#poison_img').attr('class', 'foodPoison lv2');
		 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv2');
				$("#leveld").html("주의");
				$('#content .alertBox .statusInfo .infoTxt').text("평소와 같은 일상이 지속되겠으나 주변에 대한 주의가 필요합니다.");
		 	}else if(value_care <= 30){
		 		$('#poison_img').attr('class', 'foodPoison lv3');
		 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv3');	 		
				$("#leveld").html("경고");
				$('#content .alertBox .statusInfo .infoTxt').text("경각심이 필요한 시기입니다. 각별히 주의하시길 바라며 혹여의 화재에 대비하시길 바랍니다."); 		
		 	}else{
		 		$('#poison_img').attr('class', 'foodPoison lv4');
		 		$('#content .alertBox .statusInfo strong i').attr('class', 'lv4');
				$("#leveld").html("위험");
				$('#content .alertBox .statusInfo .infoTxt').text("화재 위험도가 높습니다. 화재 우려품을 정비하시길 바랍니다.");
		 	}
		},
		error: function(request, status, error) {
			console.log("error");
		}
	})
	
	

	//해당 월에 가장 높은 화재를 보였던 시/군/구 or 동
	$.ajax({
		url: 'http://localhost:9000/learning-fullcity',
		type: 'GET',
		dataType : 'json',
		data : {1:getMonth},
		success: function(response) {
			var fitest = response;
			var chart1 = c3.generate({
			bindto: '#chart1',
			data: {
				json: response,
				type : 'pie',
			},
			legend: {
				position: 'right'
			}
		});
		},
		error: function(request, status, error) {
			console.log("error");
		}
	})
	
	
	//해당 월에 가장 높은 화재요인 대분류
	$.ajax({
		url: 'http://localhost:9000/learning-fireMain',
		type: 'GET',
		dataType : 'json',
		data : {1:getMonth},
		success: function(response) {
			var fitest = response;
			var chart2 = c3.generate({
			bindto: '#chart2',
			data: {
				json: response,
				type : 'pie',
			},
			legend: {
				position: 'right'
			}
			});
		},
		error: function(request, status, error) {
			console.log("error");
		}
	})

	// 발화 원인 이미지 
	var imglocation = "plugins/images/causeofignition/";
	var imglistar;
	$.ajax({
	    url: 'http://localhost:9000/learning-fireElement',
	    type: 'GET',
	    dataType: 'json',
	    data : {1:getMonth},
	    success: function(response) {
			for (var i = 0; i < 3; i++) {
				var imgcounte = i;
				imglistar = Object.keys(response)[i]
				
				if(imgcounte==0){
					idaddressnum = $('#deimglist01');
				}else if(imgcounte==1){
					idaddressnum = $('#deimglist02');
				}else{
					idaddressnum = $('#deimglist03');
				}
				
				if(imglistar == '담배꽁초'){
					idaddressnum.attr('src',imglocation+"tobacco_fire.png");
				}else if(imglistar == '쓰레기 소각'){
					idaddressnum.attr('src',imglocation+"trash_fire.png");
				}else if(imglistar == '음식물 조리중'){
					idaddressnum.attr('src',imglocation+"cooking_fire.png");
				}else if(imglistar == '절연열화에 의한 단락'){
					idaddressnum.attr('src',imglocation+"electric_fire.png");
				}else if(imglistar == '불씨,불꽃,화원방치'){
					idaddressnum.attr('src',imglocation+"neglect_fire.png");
				}else if(imglistar == '기타(부주의)'){
					idaddressnum.attr('src',imglocation+"carelessness_fire.png");
				}else{
					idaddressnum.attr('src',imglocation+"unknown_fire.png");
				}
			};
			
		},
		error: function(request, status, error) {
			console.log("error");
	    }
	 });
	
	
	
})






