/**
 * 티맵 api 교정본
 */
var map;
//출발지,도착지 마커
var marker_e, marker_p;

//경로그림정보

var chktraffic = [];
var resultdrawArr = [];
var resultMarkerArr = [];

var totaladd;
var firestationa;
var firestationb;
var ad1;
var ad2;
var ad3;
var ad4;

var delcnt = 0;


//시작시 바로 시작(바디태그에 설정 됨)
function initTmap() {
	// 1. 지도 띄우기
	map = new Tmapv2.Map("map_div", {
		center : new Tmapv2.LatLng(35.1595454, 126.8526012),
		width : "100%",
		height : "910px",
		zoom : 11,
		zoomControl : true,
		scrollwheel : true

	});
	// 마커 초기화
	marker_e = new Tmapv2.Marker(
		{
			icon : "http://tmapapi.sktelecom.com/upload/tmap/marker/pin_b_m_a.png",
			iconSize : new Tmapv2.Size(24, 38),
			map : map
		});
	
	map.setOptions({zoomControl:false}); // 지도 옵션 줌컨트롤 표출 비활성화
	
	
	
	// 검색버튼 클릭
	$("#btn_select").click(function() {
		
		//선택,입력 주소 모음
		ad1 = $("#address1").val();
		ad2 = $("#address2").val();
		ad3 = $("#address3").val();
		ad4 = $("#address4").val();
		totaladd = ad1+ad2+ad3+ad4;
		
		//주소 빈칸 검증 
		if(ad1==""||ad2==""||ad3==""||ad4==""){
			alert("주소를 입력해주세요")
		}else{	//주소 입력시 작동
			
		//검색 후 정보 시각화
		$("#data_set").show();
		
		
		
		
		
		
		
		// 지도 api 실행 
		//최초 실행 이후에 기존 경로를 없애기 위해 1회를 세기위한 변수
		delcnt++;
		if(delcnt>0){
		
			//기존마커는 삭제
			if (resultMarkerArr.length > 0) {
				for (var i = 0; i < resultMarkerArr.length; i++) {
					resultMarkerArr[i].setMap(null);
				}
			}
			if (resultdrawArr.length > 0) {
				for (var i = 0; i < resultdrawArr.length; i++) {
					resultdrawArr[i].setMap(null);
				}
			}
			chktraffic = [];
			resultMarkerArr = [];
			resultdrawArr = [];
		}
		
		
		
		
		
		//소방서 위도,경도 리스트
		var firestationa =[];
		var firestationb =[];
		//가까운 소방서 위도,경도를 저장할 함수
		var listfireenda;
		var listfireendb;
		
		
		//풍암 119안전센터
		firestationa[0] = 35.123450253870764;
		firestationb[0] = 126.86285904790341;
		//상무 119안전센터
		firestationa[1] = 35.15322412396225;
		firestationb[1] = 126.84732364849691;
		//금호 119안전센터
		firestationa[2] = 35.142595816084665;
		firestationb[2] = 126.8580718210487;
		//염주 119안전센터
		firestationa[3] = 35.141418146199754;
		firestationb[3] = 126.87393333286306;
		//화정 119안전센터
		firestationa[4] = 35.15648524079681;
		firestationb[4] = 126.87672179677901;
		
		//용산119안전센터
		firestationa[5] = 35.118987203878355;
		firestationb[5] = 126.93273051768209;
		//지산119안전센터
		firestationa[6] = 35.150020037778305;
		firestationb[6] = 126.93853363353968;
		//대인119안전센터
		firestationa[7] = 35.15451107949204;
		firestationb[7] = 126.91494339405041;
		
		//동림 119안전센터
		firestationa[8] = 35.18632285021091;
		firestationb[8] = 126.87023974609909;
		//일곡 119안전센터
		firestationa[9] = 35.20632849386593;
		firestationb[9] = 126.89753741201154;
		//임동 119안전센터
		firestationa[10] = 35.168888777736896;
		firestationb[10] = 126.89053991267828;
		//두암 119안전센터
		firestationa[11] = 35.16223223645584;
		firestationb[11] = 126.93685232769265;
		//우산 119안전센터
		firestationa[12] = 35.174397253358414;
		firestationb[12] = 126.92609857296894;
		//문흥 119안전센터
		firestationa[13] = 35.186588975287776;
		firestationb[13] = 126.9119745921562;
		
		//봉선 119안전센터
		firestationa[14] = 35.150020037778305;
		firestationb[14] = 126.93853363353968;
		//월산 119안전센터
		firestationa[15] = 35.13235532126279;
		firestationb[15] = 126.92884011016132;
		//송하 119안전센터
		firestationa[16] = 35.15451107949204;
		firestationb[16] = 126.91494339405041;
		
		//평동 119안전센터
		firestationa[17] = 35.124442668530904;
		firestationb[17] = 126.77417065929421;
		//첨단 119안전센터
		firestationa[18] = 35.218701597730295;
		firestationb[18] = 126.84885021057136;
		//신가 119안전센터
		firestationa[19] = 35.18503580062779;
		firestationb[19] = 126.83477830829277;
		//비아 119안전센터
		firestationa[20] = 35.22069755698849;
		firestationb[20] = 126.8235176061246;
		//월곡 119안전센터
		firestationa[21] = 35.168913098326954;
		firestationb[21] = 126.80912747472262;
		//송정 119안전센터
		firestationa[22] = 35.129005663747755;
		firestationb[22] = 126.78573174783266;
		//하남 119안전센터
		firestationa[23] = 35.18581976176438;
		firestationb[23] = 126.79667595553859;
		
		
		
		
		// 2. API 사용요청(T-map)
		// 주소 값 입력
		$.ajax({
			method : "GET",
			url : "https://apis.openapi.sk.com/tmap/geo/fullAddrGeo?version=1&format=json&callback=result",
			async : false,
			data : {
				"appKey" : "l7xx5e58e38228af45558a479db704a44197",
				"coordType" : "WGS84GEO",
				"fullAddr" : totaladd
			},
			success : function(response) {
				
				var resultInfo = response.coordinateInfo; // .coordinate[0];
				
				
				// 3.마커 찍기
				// 검색 결과 정보가 없을 때 처리
				if (resultInfo.coordinate.length == 0) {
					$("#result").text(
					"요청 데이터가 올바르지 않습니다.");
				} else {
					//검색된 주소지 위도,경도
					var lon, lat;
					var resultCoordinate = resultInfo.coordinate[0];
					if (resultCoordinate.lon.length > 0) {
						// 구주소
						lon = resultCoordinate.lon;
						lat = resultCoordinate.lat;
					} else { 
						// 신주소
						lon = resultCoordinate.newLon;
						lat = resultCoordinate.newLat
					}
					
					var markerPosition = new Tmapv2.LatLng(Number(lat),Number(lon));
					
					
					
					//검색 후 지도 위치 줌 크기
					map.setCenter(markerPosition);
					map.setZoom(15);
					
					
					
					if (resultCoordinate.matchFlag.length > 0) {
						// 매칭 구분 코드
						matchFlag = resultCoordinate.matchFlag;
						
						
						
						// 최단거리 소방서 비교 반복문
						var pa = (firestationa[0]-lat)*100000000;
						var pb = (firestationb[0]-lon)*100000000;
						var pabsum = Math.pow(pa,2)+Math.pow(pb,2);
						var endpab = pabsum;
						listfireendb = firestationb[0];
						listfireenda = firestationa[0];
						
						for(var i=0; i<firestationa.length;i++){
							var pa = (firestationa[i]-lat)*100000000;
							var pb = (firestationb[i]-lon)*100000000;
							var pabsum = Math.pow(pa,2)+Math.pow(pb,2);
							if(endpab>pabsum){
								endpab=pabsum;
								listfireendb = firestationb[i];
								listfireenda = firestationa[i];
							}
						}
						
						// 3. 경로탐색 API 사용요청(길찾기)
						//값 선택
						var searchOption = "2";//길 찾는 유형(그냥 고정시킴)
						var trafficInfochk = "Y";//도로 교통상황 색으로 나타내는 값
												
						//JSON TYPE EDIT [S]
						$
								.ajax({
									type : "POST",
									url : "https://apis.openapi.sk.com/tmap/routes?version=1&format=json&callback=result",
									async : false,
									data : {
										"appKey" : "l7xx5e58e38228af45558a479db704a44197",
										"startX" : listfireendb,//시작 좌표
										"startY" : listfireenda,
										"endX" : lon,//끝 좌표
										"endY" : lat,
										"reqCoordType" : "WGS84GEO",
										"resCoordType" : "EPSG3857",
										"searchOption" : searchOption,
										"trafficInfo" : trafficInfochk
									},
									success : function(response) {
				
										var resultData = response.features;
				
										var tDistance = "소방서까지 거리 : "
												+ (resultData[0].properties.totalDistance / 1000)
														.toFixed(1) + "km,";
										var tTime = " 차량 이동 소요 시간 : "
												+ (resultData[0].properties.totalTime / 60)
														.toFixed(0) + "분";
															
										//시간 거리 결과 전송
										$("#result").text(
												tDistance + tTime);
										var label ="<span style='background-color: white;color:black'>"+tDistance + tTime+"</span>";
										marker_e.setMap(null);
										// p마커(검색주소) 올리기
										marker_e = new Tmapv2.Marker(
											{
												position : markerPosition,
												icon : "http://tmapapi.sktelecom.com/upload/tmap/marker/pin_b_m_a.png",
												iconSize : new Tmapv2.Size(
												24, 38),
												map : map,
												label: label
											});
					
										//교통정보 표출 옵션값을 체크
											for ( var i in resultData) { //for문 [S]
												var geometry = resultData[i].geometry;
												var properties = resultData[i].properties;
				
												if (geometry.type == "LineString") {
													//교통 정보도 담음
													chktraffic
															.push(geometry.traffic);
													var sectionInfos = [];
													var trafficArr = geometry.traffic;
					
													for ( var j in geometry.coordinates) {
													// 경로들의 결과값들을 포인트 객체로 변환 
														var latlng = new Tmapv2.Point(
															geometry.coordinates[j][0],
															geometry.coordinates[j][1]);
														// 포인트 객체를 받아 좌표값으로 변환
														var convertPoint = new Tmapv2.Projection.convertEPSG3857ToWGS84GEO(
																latlng);
					
														sectionInfos
																.push(convertPoint);
													}
					
													drawLine(sectionInfos,
															trafficArr);
												} else {
					
													var markerImg = "";
													var pType = "";
				
													if (properties.pointType == "S") { //출발지 마커
														markerImg = "img/fire.png";
														pType = "S";
													} else if (properties.pointType == "E") { //도착지 마커
														markerImg = "img/home.png";
														pType = "E";
													} else { //각 포인트 마커
														markerImg = "http://topopen.tmap.co.kr/imgs/point.png";
														pType = "P"
													}
					
													// 경로들의 결과값들을 포인트 객체로 변환 
												var latlon = new Tmapv2.Point(
															geometry.coordinates[0],
															geometry.coordinates[1]);
													// 포인트 객체를 받아 좌표값으로 다시 변환
													var convertPoint = new Tmapv2.Projection.convertEPSG3857ToWGS84GEO(
															latlon);
					
													var routeInfoObj = {
														markerImage : markerImg,
														lng : convertPoint._lng,
														lat : convertPoint._lat,
														pointType : pType
													};
													// 마커 추가
													addMarkers(routeInfoObj);
																			
												}
											}//for문 [E]
									},
									error : function(request, status, error) {
										console.log("code:"
												+ request.status + "\n"
												+ "message:"
												+ request.responseText
												+ "\n" + "error:" + error);
									}
															
								});
							
						//JSON TYPE EDIT [E]
					
						function addComma(num) {
							var regexp = /\B(?=(\d{3})+(?!\d))/g;
							return num.toString().replace(regexp, ',');
						}
						
						
						//마커 생성하기
						function addMarkers(infoObj) {
							var size = new Tmapv2.Size(24, 38);//아이콘 크기 설정합니다.
					
							if (infoObj.pointType == "P") { //포인트점일때는 아이콘 크기를 줄입니다.
								size = new Tmapv2.Size(8, 8);
							}
					
							marker_p = new Tmapv2.Marker({
								position : new Tmapv2.LatLng(infoObj.lat, infoObj.lng),
								icon : infoObj.markerImage,
								iconSize : size,
								map : map
							});
					
							resultMarkerArr.push(marker_p);
						}
					
						//라인그리기
						function drawLine(arrPoint, traffic) {
							var polyline_;
					
							if (chktraffic.length != 0) {
					
								// 교통정보 혼잡도를 체크
								// strokeColor는 교통 정보상황에 다라서 변화
								// traffic :  0-정보없음, 1-원활, 2-서행, 3-지체, 4-정체  (black, green, yellow, orange, red)
					
								var lineColor = "";
					
								if (traffic != "0") {
									if (traffic.length == 0) { //length가 0인것은 교통정보가 없으므로 검은색으로 표시
					
										lineColor = "#06050D";
										//라인그리기[S]
										polyline_ = new Tmapv2.Polyline({
											path : arrPoint,
											strokeColor : lineColor,
											strokeWeight : 6,
											map : map
										});
										resultdrawArr.push(polyline_);
										//라인그리기[E]
									} else { //교통정보가 있음
					
										if (traffic[0][0] != 0) { //교통정보 시작인덱스가 0이 아닌경우
											var trafficObject = "";
											var tInfo = [];
					
											for (var z = 0; z < traffic.length; z++) {
												trafficObject = {
													"startIndex" : traffic[z][0],
													"endIndex" : traffic[z][1],
													"trafficIndex" : traffic[z][2],
												};
												tInfo.push(trafficObject)
											}
					
											var noInfomationPoint = [];
					
											for (var p = 0; p < tInfo[0].startIndex; p++) {
												noInfomationPoint.push(arrPoint[p]);
											}
					
											//라인그리기[S]
											polyline_ = new Tmapv2.Polyline({
												path : noInfomationPoint,
												strokeColor : "#06050D",
												strokeWeight : 6,
												map : map
											});
											//라인그리기[E]
											resultdrawArr.push(polyline_);
					
											for (var x = 0; x < tInfo.length; x++) {
												var sectionPoint = []; //구간선언
					
												for (var y = tInfo[x].startIndex; y <= tInfo[x].endIndex; y++) {
													sectionPoint.push(arrPoint[y]);
												}
					
												if (tInfo[x].trafficIndex == 0) {
													lineColor = "#06050D";
												} else if (tInfo[x].trafficIndex == 1) {
													lineColor = "#61AB25";
												} else if (tInfo[x].trafficIndex == 2) {
													lineColor = "#FFFF00";
												} else if (tInfo[x].trafficIndex == 3) {
													lineColor = "#E87506";
												} else if (tInfo[x].trafficIndex == 4) {
													lineColor = "#D61125";
												}
					
												//라인그리기[S]
												polyline_ = new Tmapv2.Polyline({
													path : sectionPoint,
													strokeColor : lineColor,
													strokeWeight : 6,
													map : map
												});
												//라인그리기[E]
												resultdrawArr.push(polyline_);
											}
										} else { //0부터 시작하는 경우
					
											var trafficObject = "";
											var tInfo = [];
					
											for (var z = 0; z < traffic.length; z++) {
												trafficObject = {
													"startIndex" : traffic[z][0],
													"endIndex" : traffic[z][1],
													"trafficIndex" : traffic[z][2],
												};
												tInfo.push(trafficObject)
											}
					
											for (var x = 0; x < tInfo.length; x++) {
												var sectionPoint = []; //구간선언
					
												for (var y = tInfo[x].startIndex; y <= tInfo[x].endIndex; y++) {
													sectionPoint.push(arrPoint[y]);
												}
					
												if (tInfo[x].trafficIndex == 0) {
													lineColor = "#06050D";
												} else if (tInfo[x].trafficIndex == 1) {
													lineColor = "#61AB25";
												} else if (tInfo[x].trafficIndex == 2) {
													lineColor = "#FFFF00";
												} else if (tInfo[x].trafficIndex == 3) {
													lineColor = "#E87506";
												} else if (tInfo[x].trafficIndex == 4) {
													lineColor = "#D61125";
												}
					
												//라인그리기[S]
												polyline_ = new Tmapv2.Polyline({
													path : sectionPoint,
													strokeColor : lineColor,
													strokeWeight : 6,
													map : map
												});
												//라인그리기[E]
												resultdrawArr.push(polyline_);
											}
										}
									}
								} else {
					
								}
							} else {
								polyline_ = new Tmapv2.Polyline({
									path : arrPoint,
									strokeColor : "#DD0000",
									strokeWeight : 6,
									map : map
								});
								resultdrawArr.push(polyline_);
							}
					
						}
					
						
						
					}
				}
			},
			error : function(request, status, error) {
				console.log(request);
				console.log("code:"+request.status + "\n message:" + request.responseText +"\n error:" + error);
				// 에러가 발생하면 맵을 초기화함
				// markerStartLayer.clearMarkers();
				// 마커초기화
				map.setCenter(new Tmapv2.LatLng(37.570028, 126.986072));
				$("#result").html("");
			
			}
		});
	
		}
	});
	
	
}